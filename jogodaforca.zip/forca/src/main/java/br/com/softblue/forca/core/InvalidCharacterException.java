package br.com.softblue.forca.core;

@SuppressWarnings("serial")
public class InvalidCharacterException extends Exception {

	public InvalidCharacterException(String message) {
		super(message);
	}

}